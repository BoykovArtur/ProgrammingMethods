import os
import json
import threading

from confluent_kafka import Consumer, OFFSET_BEGINNING

from .producer import proceed_to_deliver


MODULE_NAME: str = os.getenv("MODULE_NAME")


def send_to_emergency(id, details):
    details["deliver_to"] = "emergency-braking"
    details["operation"] = "movement_done"
    proceed_to_deliver(id, details)


def send_to_self_diagnostic(id, details):
    details["deliver_to"] = "self-diagnostic"
    details["operation"] = "report_movement_status"
    proceed_to_deliver(id, details)


def handle_event(id, details_str):
    """Заглушка системы передвижения."""
    details = json.loads(details_str)

    source: str = details.get("source")
    deliver_to: str = details.get("deliver_to")
    data: dict = details.get("data", {})
    operation: str = details.get("operation")

    print(f"[info] handling event {id}, "
          f"{source}->{deliver_to}: {operation}")

    messages = {
        "move_forward": "Робот переместился вперёд",
        "move_backward": "Робот переместился назад",
        "rotate": "Робот повернулся",
        "stop": "Робот остановлен",
        "move_to_base": "Робот едет на базу",
    }

    details["data"] = {
        "moved": operation != "stop",
        "stopped": operation == "stop",
        "message": messages.get(operation, "Движение выполнено"),
        **data,
    }
    details["operation"] = "movement_done"
    send_to_self_diagnostic(id, dict(details))
    return send_to_emergency(id, details)


def consumer_job(args, config):
    consumer = Consumer(config)

    def reset_offset(verifier_consumer, partitions):
        if not args.reset:
            return
        for p in partitions:
            p.offset = OFFSET_BEGINNING
        verifier_consumer.assign(partitions)

    topic = MODULE_NAME
    consumer.subscribe([topic], on_assign=reset_offset)

    try:
        while True:
            msg = consumer.poll(1.0)
            if msg is None:
                pass
            elif msg.error():
                print(f"[error] {msg.error()}")
            else:
                try:
                    id = msg.key().decode('utf-8')
                    details_str = msg.value().decode('utf-8')
                    handle_event(id, details_str)
                except Exception as e:
                    print(f"[error] Malformed event received from "
                          f"topic {topic}: {msg.value()}. {e}")
    except KeyboardInterrupt:
        pass
    finally:
        consumer.close()


def start_consumer(args, config):
    print(f'{MODULE_NAME}_consumer started')
    threading.Thread(target=lambda: consumer_job(args, config)).start()
